# Analysis of Olympic Medal Trends (1896-2008)

This project performs a historical analysis of Olympic medal data to identify trends in country dominance, athlete performance, gender participation, and sport popularity. The insights are intended to support strategic decisions for the International Olympic Committee (IOC).

### Project Modules

The analysis is broken down into four key modules as requested:
1.  **Country-Wise Medal Distribution:** Ranks the top 10 medal-winning nations.
2.  **Athlete-Level Performance:** Identifies the most decorated athletes in Olympic history.
3.  **Temporal Gender Analysis:** Tracks the evolution of male vs. female athlete participation over the years.
4.  **Sport-Specific Medal Trends:** Determines which sports have yielded the most medals.

### How to Run the Project

1.  **Clone the Repository:**
    ```bash
    git clone <your-repo-url>
    cd olympic-medal-analysis
    ```

2.  **Install Dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

3.  **Execute the Analysis:**
    ```bash
    python main.py
    ```
    The script will run the full analysis pipeline, print summary results to your terminal, and save all charts to the `reports/figures/` directory.