import os
from src import data_loader, analysis, visualizations

def main():
    """
    Main function to run the entire Olympic analysis pipeline.
    """
    # Create figures directory if it doesn't exist
    if not os.path.exists('reports/figures'):
        os.makedirs('reports/figures')

    # Load and process data
    df = data_loader.load_data()
    df = analysis.add_performance_category(df)

    # Perform analyses and get data for plotting
    top_countries_data = analysis.get_top_10_countries(df)
    top_athletes_data = analysis.find_top_athletes(df)
    gender_trends_data = analysis.analyze_gender_trends(df)
    sport_trends_data = analysis.analyze_sport_trends(df)

    # Generate and save visualizations
    visualizations.plot_top_10_countries(top_countries_data)
    visualizations.plot_top_athletes(top_athletes_data)
    visualizations.plot_gender_trends(gender_trends_data)
    visualizations.plot_sport_trends(sport_trends_data)

    print("\n✅ Analysis complete. All charts have been saved to 'reports/figures/'.")

if __name__ == "__main__":
    main()