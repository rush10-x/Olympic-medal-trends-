import pandas as pd

def add_performance_category(df):
    """Creates a 'Performance Category' based on the medal won."""
    conditions = [
        (df['Medal'] == 'Gold'),
        (df['Medal'] == 'Silver'),
        (df['Medal'] == 'Bronze')
    ]
    choices = ['Top Performer', 'Outstanding Performer', 'Great Performer']
    df['Performance Category'] = pd.np.select(conditions, choices, default='No Medal')
    return df

def get_top_10_countries(df):
    """Module 1: Ranks nations by total medals and returns the top 10."""
    print("\n--- Module 1: Top 10 Medal-Winning Countries ---")
    top_10_countries = df['NOC'].value_counts().nlargest(10)
    print(top_10_countries)
    return top_10_countries

def find_top_athletes(df):
    """Module 2: Highlights repeat medalists by counting medals per athlete."""
    print("\n--- Module 2: Top 10 Most Decorated Athletes ---")
    top_10_athletes = df['Athlete'].value_counts().nlargest(10)
    print(top_10_athletes)
    return top_10_athletes

def analyze_gender_trends(df):
    """Module 3: Analyzes male vs. female participation over time."""
    print("\n--- Module 3: Analyzing Gender Participation Trends ---")
    gender_trends = df.groupby(['Edition', 'Gender'])['Athlete'].nunique().unstack().fillna(0)
    print(gender_trends.tail()) # Display recent trends
    return gender_trends

def analyze_sport_trends(df):
    """Module 4: Determines which sports yield the highest medal counts."""
    print("\n--- Module 4: Analyzing Medal Counts by Sport ---")
    sport_trends = df.groupby(['Sport', 'Medal']).size().unstack(fill_value=0)
    sport_trends['Total'] = sport_trends.sum(axis=1)
    sport_trends = sport_trends.sort_values('Total', ascending=False)
    print(sport_trends)
    return sport_trends