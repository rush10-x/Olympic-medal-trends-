import matplotlib.pyplot as plt
import seaborn as sns

FIGURES_DIR = 'reports/figures'

def plot_top_10_countries(data):
    """Saves a bar chart of top 10 countries by medal count."""
    print("Creating plot for Module 1...")
    plt.figure(figsize=(12, 7))
    sns.barplot(x=data.index, y=data.values, palette='viridis')
    plt.title('Top 10 Countries by Total Medals Won', fontsize=16)
    plt.xlabel('Country (NOC)', fontsize=12)
    plt.ylabel('Total Medals', fontsize=12)
    plt.savefig(f'{FIGURES_DIR}/01_top_10_countries.png', bbox_inches='tight')
    plt.close()

def plot_top_athletes(data):
    """Saves a bar chart of top 10 athletes by medal count."""
    print("Creating plot for Module 2...")
    plt.figure(figsize=(12, 7))
    sns.barplot(x=data.index, y=data.values, palette='plasma')
    plt.title('Top 10 Most Decorated Athletes', fontsize=16)
    plt.xlabel('Athlete', fontsize=12)
    plt.ylabel('Total Medals', fontsize=12)
    plt.xticks(rotation=45, ha='right')
    plt.savefig(f'{FIGURES_DIR}/02_top_10_athletes.png', bbox_inches='tight')
    plt.close()

def plot_gender_trends(data):
    """Saves a dual-line chart of athlete participation by gender over time."""
    print("Creating plot for Module 3...")
    plt.figure(figsize=(14, 7))
    data.plot(kind='line', ax=plt.gca(), marker='o')
    plt.title('Evolution of Athlete Participation by Gender', fontsize=16)
    plt.xlabel('Olympic Edition (Year)', fontsize=12)
    plt.ylabel('Number of Unique Athletes', fontsize=12)
    plt.legend(title='Gender')
    plt.grid(True)
    plt.savefig(f'{FIGURES_DIR}/03_gender_participation_trends.png', bbox_inches='tight')
    plt.close()

def plot_sport_trends(data):
    """Saves a stacked bar chart of medals by sport."""
    print("Creating plot for Module 4...")
    # Select only the medal columns for plotting
    medals_data = data[['Gold', 'Silver', 'Bronze']]
    medals_data.plot(kind='bar', stacked=True, figsize=(14, 8), colormap='YlGnBu')
    plt.title('Medal Distribution by Sport', fontsize=16)
    plt.xlabel('Sport', fontsize=12)
    plt.ylabel('Total Number of Medals', fontsize=12)
    plt.xticks(rotation=45, ha='right')
    plt.legend(title='Medal Type')
    plt.savefig(f'{FIGURES_DIR}/04_medals_by_sport.png', bbox_inches='tight')
    plt.close()