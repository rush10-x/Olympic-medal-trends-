import pandas as pd
import numpy as np

def load_data():
    """
    Generates a sample Olympic medals DataFrame.
    In a real project, this would load data from a file.
    """
    print("Loading data...")
    years = np.arange(1896, 2009, 4)
    countries = ['USA', 'URS', 'GBR', 'FRA', 'GER', 'CHN', 'AUS', 'SWE', 'HUN', 'ITA']
    sports = ['Aquatics', 'Athletics', 'Gymnastics', 'Fencing', 'Cycling']
    medals = ['Gold', 'Silver', 'Bronze']
    genders = ['Men', 'Women']

    data = {
        'Edition': np.random.choice(years, 500),
        'NOC': np.random.choice(countries, 500),
        'Sport': np.random.choice(sports, 500),
        'Athlete': [f'Athlete_{i}' for i in np.random.randint(1, 200, 500)],
        'Gender': np.random.choice(genders, 500, p=[0.7, 0.3]),
        'Medal': np.random.choice(medals, 500, p=[0.33, 0.33, 0.34]),
    }
    df = pd.DataFrame(data)
    # Simulate increasing women participation over time
    df.loc[df['Edition'] > 1980, 'Gender'] = np.random.choice(genders, df[df['Edition'] > 1980].shape[0], p=[0.5, 0.5])
    return df